import React from 'react';
import { motion } from 'framer-motion';
import { Users, Target, TrendingUp, Award, Clock } from 'lucide-react';
import { coachData, activeMissions } from '../utils/mockData';

const Coach: React.FC = () => {
  const coachMission = coachData.currentMission;
  const progressPercentage = coachMission ? (coachMission.current / coachMission.target) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Coach Collaboration</h2>
        <p className="text-gray-600">Work together for collective rewards</p>
      </div>

      {/* Coach Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-xl shadow-lg"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-blue-100">Coach {coachData.coachNumber}</p>
            <p className="text-2xl font-bold">{coachData.trainNumber}</p>
          </div>
          <div className="bg-white/20 p-3 rounded-full">
            <Users size={24} />
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-3xl font-bold">{coachData.totalFamilies}</p>
            <p className="text-blue-100 text-sm">Families</p>
          </div>
          <div>
            <p className="text-3xl font-bold">{coachData.averageScore}</p>
            <p className="text-blue-100 text-sm">Avg Score</p>
          </div>
          <div>
            <p className="text-3xl font-bold">{coachData.totalPoints.toLocaleString()}</p>
            <p className="text-blue-100 text-sm">Total Points</p>
          </div>
        </div>
      </motion.div>

      {/* Active Coach Mission */}
      {coachMission && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 p-4"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <Target className="text-green-600" size={24} />
              <h3 className="font-semibold text-gray-800">Active Coach Mission</h3>
            </div>
            {coachMission.deadline && (
              <div className="flex items-center space-x-1 text-orange-600 text-sm">
                <Clock size={14} />
                <span className="font-medium">
                  {Math.floor((coachMission.deadline.getTime() - Date.now()) / (1000 * 60 * 60))}h remaining
                </span>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <p className="font-medium text-gray-800 mb-1">{coachMission.title}</p>
              <p className="text-sm text-gray-600">{coachMission.description}</p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Collective Progress</span>
                <span className="font-medium">{coachMission.current} / {coachMission.target}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(progressPercentage, 100)}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="bg-gradient-to-r from-green-500 to-emerald-500 h-3 rounded-full"
                />
              </div>
              <div className="flex justify-between text-xs text-gray-600">
                <span>{progressPercentage.toFixed(1)}% complete</span>
                <span>{coachMission.participants.length} families participating</span>
              </div>
            </div>

            <div className="bg-green-50 p-3 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-800">Mission Reward</p>
                  <p className="text-xs text-green-600">Per participating family</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">{coachMission.reward} pts</p>
                  <p className="text-xs text-green-600">+{coachMission.ecoCredits} eco-credits</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Family Contributions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-xl shadow-sm border border-gray-100 p-4"
      >
        <div className="flex items-center space-x-3 mb-4">
          <TrendingUp className="text-blue-600" size={24} />
          <h3 className="font-semibold text-gray-800">Family Contributions</h3>
        </div>

        <div className="space-y-3">
          {coachData.families.map((family, index) => (
            <motion.div
              key={family.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className={`flex items-center justify-between p-3 rounded-lg ${
                family.id === '1' ? 'bg-orange-50 border border-orange-200' : 'bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <span className="text-xl">{family.avatar}</span>
                <div>
                  <p className="font-medium text-gray-800">
                    {family.name}
                    {family.id === '1' && (
                      <span className="ml-2 text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full">
                        You
                      </span>
                    )}
                  </p>
                  <p className="text-sm text-gray-600">{family.members} members</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-800">{family.totalPoints.toLocaleString()}</p>
                <p className="text-xs text-gray-600">total points</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Collaboration Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4"
      >
        <div className="flex items-center space-x-3 mb-3">
          <Award className="text-green-600" size={24} />
          <h3 className="font-semibold text-green-800">Team Success Tips</h3>
        </div>
        
        <div className="space-y-2 text-sm text-green-700">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Maintain your berth and surrounding area consistently</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Use designated waste disposal bins properly</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Upload verification photos regularly</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Encourage other families to participate</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Coach;