import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Star, TrendingUp, Award, Zap, Target, Users } from 'lucide-react';
import { currentUser, activeMissions, recentScores } from '../utils/mockData';
import { getScoreColor, getScoreGrade } from '../utils/scoring';

const Dashboard: React.FC = () => {
  const journey = currentUser.currentJourney;
  const activeMission = activeMissions.find(m => m.type === 'individual' && m.isActive);

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-4"
      >
        <h2 className="text-4xl font-black text-gray-900 mb-3 tracking-tight">Welcome Back! 👋</h2>
        <p className="text-gray-800 font-bold text-xl">Let's keep our railways clean together</p>
      </motion.div>

      {/* Journey Status */}
      {journey && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100 rounded-3xl shadow-2xl border-2 border-blue-200/60 p-8 relative overflow-hidden"
        >
          {/* Enhanced Background Pattern */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-blue-200/30 rounded-full -translate-y-20 translate-x-20"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-200/30 rounded-full translate-y-16 -translate-x-16"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-black text-indigo-900 text-2xl">🚄 Current Journey</h3>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse shadow-lg"></div>
                <span className="text-sm bg-green-100 text-green-900 px-4 py-2 rounded-full font-black border-2 border-green-200 shadow-lg">
                  On Time
                </span>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 border-2 border-white/80 shadow-xl">
                <p className="font-black text-indigo-900 text-2xl mb-2">{journey.trainName}</p>
                <p className="text-indigo-800 font-bold text-xl">{journey.trainNumber} • Coach {journey.coach}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-5">
                <div className="flex items-center space-x-4 bg-white/80 rounded-2xl p-5 border-2 border-white/60 shadow-lg">
                  <div className="p-3 bg-blue-200 rounded-xl shadow-lg">
                    <MapPin size={20} className="text-blue-900" />
                  </div>
                  <div>
                    <p className="font-black text-indigo-900 text-lg">{journey.from}</p>
                    <p className="text-indigo-800 text-base font-bold">to {journey.to}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4 bg-white/80 rounded-2xl p-5 border-2 border-white/60 shadow-lg">
                  <div className="p-3 bg-blue-200 rounded-xl shadow-lg">
                    <Clock size={20} className="text-blue-900" />
                  </div>
                  <div>
                    <p className="font-black text-indigo-900 text-lg">
                      {journey.estimatedArrival.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-indigo-800 text-base font-bold">ETA</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="font-black text-indigo-900 text-lg">Journey Progress</span>
                  <span className="font-black text-indigo-900 text-2xl">{journey.progressPercentage}%</span>
                </div>
                <div className="w-full bg-blue-200/80 rounded-full h-5 overflow-hidden border-2 border-blue-300/50 shadow-inner">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${journey.progressPercentage}%` }}
                    transition={{ duration: 1.5, delay: 0.5 }}
                    className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 h-5 rounded-full shadow-lg"
                  />
                </div>
                <div className="flex justify-between">
                  <span className="text-indigo-800 font-bold text-base">Current: {journey.currentStation}</span>
                  <span className="text-indigo-800 font-bold text-base">Next: {journey.nextStation}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Active Mission */}
      {activeMission && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-purple-50 via-pink-50 to-rose-100 rounded-3xl border-2 border-purple-200/60 p-8 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-200/40 rounded-full -translate-y-16 translate-x-16"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <div className="p-4 bg-purple-200/80 rounded-2xl border-2 border-purple-300/50 shadow-lg">
                  <Target className="text-purple-900" size={26} />
                </div>
                <h3 className="font-black text-purple-900 text-2xl">🎯 Active Mission</h3>
              </div>
              <Award className="text-purple-800" size={32} />
            </div>
            
            <div className="space-y-6">
              <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 border-2 border-white/80 shadow-xl">
                <p className="font-black text-purple-900 text-xl mb-3">{activeMission.title}</p>
                <p className="text-purple-800 font-bold text-lg">{activeMission.description}</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="font-black text-purple-900 text-lg">Mission Progress</span>
                  <span className="font-black text-purple-900 text-2xl">{activeMission.current}% / {activeMission.target}%</span>
                </div>
                <div className="w-full bg-purple-200/80 rounded-full h-5 overflow-hidden border-2 border-purple-300/50 shadow-inner">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(activeMission.current / activeMission.target) * 100}%` }}
                    transition={{ duration: 1.5, delay: 0.7 }}
                    className="bg-gradient-to-r from-purple-600 via-pink-600 to-rose-700 h-5 rounded-full shadow-lg"
                  />
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-800 font-black text-base">🎁 Reward: {activeMission.reward} points</span>
                  <span className="text-green-800 font-black text-base">🌱 +{activeMission.ecoCredits} eco-credits</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="p-4 bg-green-100 rounded-2xl border-2 border-green-200 shadow-lg">
              <TrendingUp className="text-green-800" size={26} />
            </div>
            <h3 className="font-black text-gray-900 text-2xl">📊 Recent Activity</h3>
          </div>
        </div>
        
        <div className="space-y-5">
          {recentScores.slice(0, 3).map((score, index) => (
            <motion.div
              key={score.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="flex items-center justify-between p-6 bg-gradient-to-r from-gray-50 via-white to-gray-50 rounded-2xl border-2 border-gray-200 hover:shadow-xl transition-all duration-300 shadow-lg"
            >
              <div className="flex items-center space-x-5">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 via-purple-600 to-pink-600 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-xl">
                  {score.area.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-black capitalize text-gray-900 text-lg">{score.area} Area</p>
                  <p className="text-gray-800 font-bold text-base">
                    {score.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-4 mb-2">
                  <span className={`text-3xl font-black ${getScoreColor(score.scoreAfter)}`}>
                    {score.scoreAfter}
                  </span>
                  <span className="text-base bg-gray-300 text-gray-900 px-4 py-2 rounded-full font-black border-2 border-gray-400 shadow-lg">
                    {getScoreGrade(score.scoreAfter)}
                  </span>
                </div>
                <p className="text-green-700 font-black text-lg">+{score.points} pts</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-2 gap-6"
      >
        <div className="bg-gradient-to-br from-yellow-50 via-orange-50 to-red-100 rounded-3xl shadow-2xl border-2 border-yellow-200 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-yellow-200/40 rounded-full -translate-y-10 translate-x-10"></div>
          <div className="relative z-10">
            <div className="p-4 bg-yellow-200/80 rounded-2xl inline-block mb-4 border-2 border-yellow-300/60 shadow-lg">
              <Star className="text-yellow-900" size={36} />
            </div>
            <p className="text-5xl font-black text-yellow-900 mb-2">#{currentUser.rank}</p>
            <p className="text-yellow-800 font-black text-lg">Overall Rank</p>
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-50 via-pink-50 to-rose-100 rounded-3xl shadow-2xl border-2 border-purple-200 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-purple-200/40 rounded-full -translate-y-10 translate-x-10"></div>
          <div className="relative z-10">
            <div className="p-4 bg-purple-200/80 rounded-2xl inline-block mb-4 border-2 border-purple-300/60 shadow-lg">
              <Award className="text-purple-900" size={36} />
            </div>
            <p className="text-5xl font-black text-purple-900 mb-2">{currentUser.achievements.length}</p>
            <p className="text-purple-800 font-black text-lg">Achievements</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;