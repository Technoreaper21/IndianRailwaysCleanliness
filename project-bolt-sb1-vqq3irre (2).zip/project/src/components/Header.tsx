import React from 'react';
import { Train, Bell, Settings, Zap } from 'lucide-react';
import { currentUser } from '../utils/mockData';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 text-white p-4 pb-6 relative overflow-hidden shadow-2xl">
      {/* Dynamic Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-48 h-48 bg-yellow-300 rounded-full -translate-x-24 -translate-y-24 animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-40 h-40 bg-cyan-300 rounded-full translate-x-20 translate-y-20 animate-bounce"></div>
        <div className="absolute top-1/2 right-1/4 w-24 h-24 bg-lime-300 rounded-full animate-pulse"></div>
        <div className="absolute top-1/4 left-1/3 w-20 h-20 bg-purple-300 rounded-full animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/4 w-16 h-16 bg-emerald-300 rounded-full animate-bounce"></div>
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="bg-white/30 backdrop-blur-sm p-4 rounded-3xl shadow-2xl border-2 border-white/40 animate-pulse">
              <Train size={36} className="text-white drop-shadow-2xl" />
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tight text-white drop-shadow-2xl animate-pulse">
                Railway CleanChallenge
              </h1>
              <p className="text-yellow-100 text-lg font-black tracking-wide drop-shadow-lg">
                Indian Railways • स्वच्छ भारत
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button className="p-4 hover:bg-white/25 rounded-2xl transition-all duration-300 active:scale-95 shadow-xl border-2 border-white/30 hover:border-white/50">
              <Bell size={26} className="text-white drop-shadow-lg" />
            </button>
            <button className="p-4 hover:bg-white/25 rounded-2xl transition-all duration-300 active:scale-95 shadow-xl border-2 border-white/30 hover:border-white/50">
              <Settings size={26} className="text-white drop-shadow-lg" />
            </button>
          </div>
        </div>
        
        <div className="bg-white/25 backdrop-blur-xl rounded-3xl p-6 border-2 border-white/40 shadow-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-5">
              <div className="w-18 h-18 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-600 rounded-3xl flex items-center justify-center text-4xl font-black text-white shadow-2xl border-3 border-white/50 animate-bounce">
                {currentUser.name.charAt(0)}
              </div>
              <div>
                <p className="text-3xl font-black text-white drop-shadow-2xl">{currentUser.name}</p>
                <p className="text-yellow-100 text-lg flex items-center space-x-2 font-black drop-shadow-lg">
                  <span>{currentUser.members} members</span>
                  <span>•</span>
                  <span className="flex items-center space-x-2">
                    <span className="w-4 h-4 bg-lime-400 rounded-full animate-pulse shadow-xl border border-white/50"></span>
                    <span className="text-lime-200 font-black">Active Journey</span>
                  </span>
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-8">
                <div className="text-center">
                  <div className="flex items-center space-x-2 justify-center mb-1">
                    <Zap size={24} className="text-yellow-300 drop-shadow-lg animate-pulse" />
                    <p className="text-4xl font-black text-white drop-shadow-2xl">
                      {currentUser.totalPoints.toLocaleString()}
                    </p>
                  </div>
                  <p className="text-yellow-100 text-sm font-black tracking-wide drop-shadow-sm">Points</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center space-x-2 justify-center mb-1">
                    <div className="w-5 h-5 bg-lime-400 rounded-full shadow-xl animate-pulse border border-white/50"></div>
                    <p className="text-4xl font-black text-lime-200 drop-shadow-2xl">
                      {currentUser.ecoCredits}
                    </p>
                  </div>
                  <p className="text-yellow-100 text-sm font-black tracking-wide drop-shadow-sm">Eco-Credits</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;