import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Crown, Medal, Star, TrendingUp } from 'lucide-react';
import { mockFamilies, coachData } from '../utils/mockData';

const Leaderboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'families' | 'coaches' | 'trains'>('families');

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="text-yellow-500" size={20} />;
      case 2: return <Medal className="text-gray-400" size={20} />;
      case 3: return <Medal className="text-amber-600" size={20} />;
      default: return <Star className="text-gray-300" size={16} />;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-gradient-to-r from-yellow-100 to-yellow-50 border-yellow-200';
      case 2: return 'bg-gradient-to-r from-gray-100 to-gray-50 border-gray-200';
      case 3: return 'bg-gradient-to-r from-amber-100 to-amber-50 border-amber-200';
      default: return 'bg-white border-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Leaderboards</h2>
        <p className="text-gray-600">See how you rank against other families</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-1">
        <div className="grid grid-cols-3 gap-1">
          {[
            { id: 'families', label: 'Families', icon: Trophy },
            { id: 'coaches', label: 'Coaches', icon: TrendingUp },
            { id: 'trains', label: 'Trains', icon: Star }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center justify-center space-x-2 py-2 px-3 rounded-lg font-medium transition-all ${
                activeTab === id
                  ? 'bg-orange-600 text-white shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon size={16} />
              <span className="text-sm">{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Families Leaderboard */}
      {activeTab === 'families' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-3"
        >
          {mockFamilies.map((family, index) => (
            <motion.div
              key={family.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`p-4 rounded-xl border-2 shadow-sm ${getRankBg(family.rank)} ${
                family.id === '1' ? 'ring-2 ring-orange-200' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    {getRankIcon(family.rank)}
                    <span className="text-2xl font-bold text-gray-700">#{family.rank}</span>
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xl">{family.avatar}</span>
                      <p className="font-semibold text-gray-800">{family.name}</p>
                      {family.id === '1' && (
                        <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full font-medium">
                          You
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{family.members} members</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-gray-800">{family.totalPoints.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">points</p>
                  <div className="flex items-center space-x-1 mt-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs text-green-600 font-medium">{family.ecoCredits} eco-credits</span>
                  </div>
                </div>
              </div>
              
              {family.achievements.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-500">Latest:</span>
                    <span className="text-sm">{family.achievements[0].icon}</span>
                    <span className="text-xs font-medium text-gray-700">{family.achievements[0].title}</span>
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Coaches Leaderboard */}
      {activeTab === 'coaches' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-3"
        >
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Crown className="text-yellow-500" size={24} />
                <div>
                  <p className="font-semibold text-gray-800">Coach {coachData.coachNumber}</p>
                  <p className="text-sm text-gray-600">{coachData.trainNumber} - {coachData.trainName}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-gray-800">{coachData.totalPoints.toLocaleString()}</p>
                <p className="text-sm text-gray-600">total points</p>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-green-600">{coachData.averageScore}</p>
                <p className="text-xs text-gray-600">Avg Score</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{coachData.totalFamilies}</p>
                <p className="text-xs text-gray-600">Families</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">#1</p>
                <p className="text-xs text-gray-600">Rank</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <p className="text-center text-gray-600">Other coaches data will be available during journey</p>
          </div>
        </motion.div>
      )}

      {/* Trains Leaderboard */}
      {activeTab === 'trains' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-3"
        >
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Crown className="text-yellow-500" size={24} />
                <div>
                  <p className="font-semibold text-gray-800">Mumbai Rajdhani Express</p>
                  <p className="text-sm text-gray-600">12951 - Premium Express</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-gray-800">47,850</p>
                <p className="text-sm text-gray-600">total points</p>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-green-600">8.4</p>
                <p className="text-xs text-gray-600">Avg Score</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">24</p>
                <p className="text-xs text-gray-600">Coaches</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">#1</p>
                <p className="text-xs text-gray-600">Rank</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <p className="text-center text-gray-600">Real-time train rankings updated every hour</p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default Leaderboard;