import React from 'react';
import { motion } from 'framer-motion';
import { Target, Users, Train, Clock, Gift, MapPin } from 'lucide-react';
import { activeMissions } from '../utils/mockData';

const Missions: React.FC = () => {
  const getMissionIcon = (type: string) => {
    switch (type) {
      case 'individual': return <Target className="text-blue-600" size={24} />;
      case 'coach': return <Users className="text-green-600" size={24} />;
      case 'train': return <Train className="text-purple-600" size={24} />;
      default: return <Target className="text-gray-600" size={24} />;
    }
  };

  const getMissionBg = (type: string) => {
    switch (type) {
      case 'individual': return 'bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200';
      case 'coach': return 'bg-gradient-to-r from-green-50 to-green-100 border-green-200';
      case 'train': return 'bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const getTimeRemaining = (deadline?: Date) => {
    if (!deadline) return null;
    const now = new Date();
    const diff = deadline.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Active Missions</h2>
        <p className="text-gray-600">Complete challenges to earn bonus rewards</p>
      </div>

      {/* Active Missions */}
      <div className="space-y-4">
        {activeMissions.map((mission, index) => (
          <motion.div
            key={mission.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-4 rounded-xl border-2 shadow-sm ${getMissionBg(mission.type)}`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                {getMissionIcon(mission.type)}
                <div>
                  <p className="font-semibold text-gray-800">{mission.title}</p>
                  <p className="text-sm text-gray-600 capitalize">{mission.type} Challenge</p>
                </div>
              </div>
              {mission.deadline && (
                <div className="flex items-center space-x-1 text-orange-600 text-sm">
                  <Clock size={14} />
                  <span className="font-medium">{getTimeRemaining(mission.deadline)}</span>
                </div>
              )}
            </div>

            <p className="text-gray-700 mb-4">{mission.description}</p>

            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span className="font-medium">
                  {mission.current} / {mission.target}
                  {mission.type === 'individual' ? '%' : ''}
                </span>
              </div>
              <div className="w-full bg-white/50 rounded-full h-3 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((mission.current / mission.target) * 100, 100)}%` }}
                  transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                  className={`h-3 rounded-full ${
                    mission.type === 'individual' ? 'bg-blue-600' :
                    mission.type === 'coach' ? 'bg-green-600' : 'bg-purple-600'
                  }`}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Gift size={14} className="text-orange-600" />
                    <span className="text-sm font-medium text-orange-600">
                      {mission.reward.toLocaleString()} pts
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium text-green-600">
                      +{mission.ecoCredits} eco-credits
                    </span>
                  </div>
                </div>
                <div className="text-xs text-gray-500">
                  {mission.participants.length} participant{mission.participants.length !== 1 ? 's' : ''}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Upcoming Challenges */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-xl shadow-sm border border-gray-100 p-4"
      >
        <h3 className="font-semibold text-gray-800 mb-3">Upcoming Station Challenges</h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <MapPin className="text-orange-600" size={20} />
              <div>
                <p className="font-medium text-gray-800">Surat Station Special</p>
                <p className="text-sm text-gray-600">Clean berth challenge</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-orange-600">500 pts</p>
              <p className="text-xs text-gray-500">in 45 min</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <MapPin className="text-blue-600" size={20} />
              <div>
                <p className="font-medium text-gray-800">Arrival Bonus</p>
                <p className="text-sm text-gray-600">Mumbai destination challenge</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-blue-600">1000 pts</p>
              <p className="text-xs text-gray-500">in 4h 20m</p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Missions;