import React from 'react';
import { Home, Trophy, Camera, Gift, Users, Train } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'dashboard', icon: Home, label: 'Home', color: 'text-blue-600', activeColor: 'from-blue-500 to-cyan-600' },
    { id: 'scanner', icon: Camera, label: 'Scan', color: 'text-green-600', activeColor: 'from-green-500 to-emerald-600' },
    { id: 'leaderboard', icon: Trophy, label: 'Ranks', color: 'text-yellow-600', activeColor: 'from-yellow-500 to-orange-600' },
    { id: 'missions', icon: Train, label: 'Missions', color: 'text-purple-600', activeColor: 'from-purple-500 to-pink-600' },
    { id: 'rewards', icon: Gift, label: 'Rewards', color: 'text-pink-600', activeColor: 'from-pink-500 to-rose-600' },
    { id: 'coach', icon: Users, label: 'Coach', color: 'text-indigo-600', activeColor: 'from-indigo-500 to-purple-600' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t-2 border-gray-200/80 px-3 py-3 z-50 shadow-2xl">
      <div className="flex justify-around max-w-md mx-auto">
        {tabs.map(({ id, icon: Icon, label, color, activeColor }) => (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={`flex flex-col items-center p-4 rounded-3xl transition-all duration-300 transform ${
              activeTab === id
                ? `text-white bg-gradient-to-br ${activeColor} scale-110 shadow-2xl border-2 border-white/50`
                : `${color} hover:text-gray-800 hover:scale-105 active:scale-95 hover:bg-gray-50 rounded-2xl`
            }`}
          >
            <div className={`p-2 rounded-2xl ${activeTab === id ? 'bg-white/20 shadow-lg' : ''}`}>
              <Icon size={22} strokeWidth={activeTab === id ? 3 : 2.5} />
            </div>
            <span className={`text-xs mt-2 font-black tracking-wide ${activeTab === id ? 'text-white drop-shadow-sm' : ''}`}>
              {label}
            </span>
            {activeTab === id && (
              <div className="absolute -top-2 w-2 h-2 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full shadow-lg animate-pulse"></div>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default Navigation;