import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, Upload, CheckCircle, AlertCircle, Sparkles, Zap, Award } from 'lucide-react';
import { simulateAIScore, calculatePoints, calculateEcoCredits, getScoreColor, getScoreGrade } from '../utils/scoring';

const Scanner: React.FC = () => {
  const [selectedArea, setSelectedArea] = useState<string>('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const areas = [
    { id: 'berth', label: 'Berth/Seat', icon: '🛏️', color: 'from-blue-500 to-blue-600' },
    { id: 'table', label: 'Table', icon: '🪑', color: 'from-green-500 to-green-600' },
    { id: 'floor', label: 'Floor Area', icon: '🧹', color: 'from-yellow-500 to-orange-500' },
    { id: 'toilet', label: 'Toilet', icon: '🚿', color: 'from-purple-500 to-purple-600' },
    { id: 'general', label: 'General Area', icon: '🏠', color: 'from-pink-500 to-pink-600' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!selectedArea || !uploadedImage) return;

    setIsScanning(true);
    setScanResult(null);

    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 3000));

    const beforeScore = Math.round((Math.random() * 3 + 5) * 10) / 10;
    const afterScore = simulateAIScore();
    const improvement = Math.max(0, afterScore - beforeScore);
    const points = calculatePoints(improvement, selectedArea);
    const ecoCredits = calculateEcoCredits(points);

    setScanResult({
      area: selectedArea,
      scoreBefore: beforeScore,
      scoreAfter: afterScore,
      improvement,
      points,
      ecoCredits,
      timestamp: new Date()
    });

    setIsScanning(false);
  };

  const resetScan = () => {
    setSelectedArea('');
    setUploadedImage(null);
    setScanResult(null);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">🤖 AI Cleanliness Scanner</h2>
        <p className="text-gray-600">Upload a photo to verify and score cleanliness</p>
      </div>

      {!scanResult ? (
        <>
          {/* Area Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6"
          >
            <h3 className="font-bold text-gray-800 mb-4 text-lg">📍 Select Area to Scan</h3>
            <div className="grid grid-cols-2 gap-4">
              {areas.map((area) => (
                <motion.button
                  key={area.id}
                  onClick={() => setSelectedArea(area.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-4 rounded-2xl border-2 transition-all duration-300 ${
                    selectedArea === area.id
                      ? `border-orange-500 bg-gradient-to-br ${area.color} text-white shadow-lg`
                      : 'border-gray-200 hover:border-gray-300 bg-gradient-to-br from-gray-50 to-gray-100'
                  }`}
                >
                  <div className="text-3xl mb-2">{area.icon}</div>
                  <p className={`text-sm font-semibold ${selectedArea === area.id ? 'text-white' : 'text-gray-700'}`}>
                    {area.label}
                  </p>
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* Image Upload */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6"
          >
            <h3 className="font-bold text-gray-800 mb-4 text-lg">📸 Upload Photo</h3>
            
            {!uploadedImage ? (
              <label className="flex flex-col items-center justify-center h-56 border-2 border-dashed border-gray-300 rounded-2xl cursor-pointer hover:border-orange-400 transition-all duration-300 bg-gradient-to-br from-gray-50 to-gray-100 hover:from-orange-50 hover:to-orange-100">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                    <Camera size={32} className="text-white" />
                  </div>
                  <p className="text-lg font-semibold text-gray-700 mb-1">Take a photo or upload</p>
                  <p className="text-sm text-gray-500">JPG, PNG up to 10MB</p>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  capture="environment"
                />
              </label>
            ) : (
              <div className="space-y-4">
                <div className="relative rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src={uploadedImage}
                    alt="Uploaded"
                    className="w-full h-56 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
                <button
                  onClick={() => setUploadedImage(null)}
                  className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                >
                  📷 Upload different photo
                </button>
              </div>
            )}
          </motion.div>

          {/* Scan Button */}
          {selectedArea && uploadedImage && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleScan}
              disabled={isScanning}
              className="w-full bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 text-white py-5 rounded-2xl font-bold text-xl shadow-2xl hover:shadow-3xl transition-all duration-300 disabled:opacity-50 relative overflow-hidden"
            >
              {isScanning ? (
                <div className="flex items-center justify-center space-x-3">
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  <span>🤖 AI Processing...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-3">
                  <Sparkles size={24} />
                  <span>✨ Scan with AI</span>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"></div>
            </motion.button>
          )}
        </>
      ) : (
        /* Scan Results */
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl shadow-lg border border-green-200/50 p-6 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-green-200/30 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="relative z-10">
              <CheckCircle className="mx-auto mb-4 text-green-600" size={56} />
              <h3 className="text-2xl font-bold text-green-800 mb-2">🎉 Scan Complete!</h3>
              <p className="text-green-700 font-medium">AI has analyzed your {scanResult.area} area</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
            <h4 className="font-bold text-gray-800 mb-6 text-lg flex items-center space-x-2">
              <Award className="text-blue-600" size={24} />
              <span>📊 Cleanliness Score</span>
            </h4>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl border border-gray-200">
                <p className="text-sm text-gray-600 font-medium mb-1">Before</p>
                <p className={`text-3xl font-bold ${getScoreColor(scanResult.scoreBefore)} mb-1`}>
                  {scanResult.scoreBefore}
                </p>
                <p className="text-xs text-gray-500 bg-gray-200 px-2 py-1 rounded-full">
                  {getScoreGrade(scanResult.scoreBefore)}
                </p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl border border-green-200">
                <p className="text-sm text-green-700 font-medium mb-1">After</p>
                <p className={`text-3xl font-bold ${getScoreColor(scanResult.scoreAfter)} mb-1`}>
                  {scanResult.scoreAfter}
                </p>
                <p className="text-xs text-green-700 bg-green-200 px-2 py-1 rounded-full">
                  {getScoreGrade(scanResult.scoreAfter)}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-50 to-indigo-100 rounded-2xl border border-blue-200">
                <div className="flex items-center space-x-3">
                  <Zap className="text-blue-600" size={24} />
                  <span className="font-bold text-blue-800">Points Earned</span>
                </div>
                <span className="text-2xl font-bold text-blue-600">+{scanResult.points}</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gradient-to-r from-green-50 to-emerald-100 rounded-2xl border border-green-200">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full"></div>
                  <span className="font-bold text-green-800">Eco-Credits</span>
                </div>
                <span className="text-2xl font-bold text-green-600">+{scanResult.ecoCredits}</span>
              </div>
            </div>
          </div>

          <motion.button
            onClick={resetScan}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-2xl font-bold text-lg hover:shadow-lg transition-all duration-300"
          >
            🔄 Scan Another Area
          </motion.button>
        </motion.div>
      )}
    </div>
  );
};

export default Scanner;