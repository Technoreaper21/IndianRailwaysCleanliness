export interface Family {
  id: string;
  name: string;
  members: number;
  avatar: string;
  totalPoints: number;
  ecoCredits: number;
  currentJourney?: Journey;
  achievements: Achievement[];
  rank: number;
}

export interface Journey {
  id: string;
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  coach: string;
  seatNumbers: string[];
  startTime: Date;
  estimatedArrival: Date;
  currentStation?: string;
  nextStation?: string;
  progressPercentage: number;
}

export interface CleanlinessScore {
  id: string;
  familyId: string;
  area: 'seat' | 'berth' | 'table' | 'floor' | 'toilet' | 'general';
  scoreBefore: number;
  scoreAfter: number;
  improvement: number;
  timestamp: Date;
  imageUrl?: string;
  aiValidated: boolean;
  points: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt: Date;
  points: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  type: 'individual' | 'coach' | 'train';
  target: number;
  current: number;
  reward: number;
  ecoCredits: number;
  deadline?: Date;
  isActive: boolean;
  participants: string[];
}

export interface CoachData {
  id: string;
  trainNumber: string;
  coachNumber: string;
  totalFamilies: number;
  averageScore: number;
  totalPoints: number;
  currentMission?: Mission;
  families: Family[];
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  cost: number;
  type: 'discount' | 'merchandise' | 'priority' | 'donation';
  available: boolean;
  image: string;
}