import { Family, Journey, Achievement, Mission, CoachData, Reward, CleanlinessScore } from '../types';

export const mockFamilies: Family[] = [
  {
    id: '1',
    name: 'Sharma Family',
    members: 4,
    avatar: '👨‍👩‍👧‍👦',
    totalPoints: 2450,
    ecoCredits: 45,
    rank: 1,
    achievements: [
      {
        id: '1',
        title: 'Clean Champion',
        description: 'Maintained perfect cleanliness score for 3 consecutive hours',
        icon: '🏆',
        rarity: 'epic',
        unlockedAt: new Date('2024-01-15'),
        points: 500
      },
      {
        id: '2',
        title: 'Eco Warrior',
        description: 'Earned 50+ eco-credits in a single journey',
        icon: '🌱',
        rarity: 'rare',
        unlockedAt: new Date('2024-01-14'),
        points: 300
      }
    ],
    currentJourney: {
      id: 'j1',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani Express',
      from: 'New Delhi',
      to: 'Mumbai Central',
      coach: 'A1',
      seatNumbers: ['12', '13', '14', '15'],
      startTime: new Date('2024-01-15T16:55:00'),
      estimatedArrival: new Date('2024-01-16T08:35:00'),
      currentStation: 'Vadodara Junction',
      nextStation: 'Surat',
      progressPercentage: 75
    }
  },
  {
    id: '2',
    name: 'Patel Family',
    members: 3,
    avatar: '👨‍👩‍👧',
    totalPoints: 2180,
    ecoCredits: 38,
    rank: 2,
    achievements: [
      {
        id: '3',
        title: 'Team Player',
        description: 'Helped coach achieve cleanliness mission',
        icon: '🤝',
        rarity: 'rare',
        unlockedAt: new Date('2024-01-14'),
        points: 250
      }
    ],
    currentJourney: {
      id: 'j2',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani Express',
      from: 'New Delhi',
      to: 'Mumbai Central',
      coach: 'A1',
      seatNumbers: ['16', '17', '18'],
      startTime: new Date('2024-01-15T16:55:00'),
      estimatedArrival: new Date('2024-01-16T08:35:00'),
      currentStation: 'Vadodara Junction',
      nextStation: 'Surat',
      progressPercentage: 75
    }
  },
  {
    id: '3',
    name: 'Kumar Family',
    members: 5,
    avatar: '👨‍👩‍👧‍👦‍👶',
    totalPoints: 1950,
    ecoCredits: 32,
    rank: 3,
    achievements: [
      {
        id: '4',
        title: 'Photo Master',
        description: 'Submitted 20+ cleanliness verification photos',
        icon: '📸',
        rarity: 'common',
        unlockedAt: new Date('2024-01-13'),
        points: 150
      }
    ],
    currentJourney: {
      id: 'j3',
      trainNumber: '12951',
      trainName: 'Mumbai Rajdhani Express',
      from: 'New Delhi',
      to: 'Mumbai Central',
      coach: 'A1',
      seatNumbers: ['19', '20', '21', '22', '23'],
      startTime: new Date('2024-01-15T16:55:00'),
      estimatedArrival: new Date('2024-01-16T08:35:00'),
      currentStation: 'Vadodara Junction',
      nextStation: 'Surat',
      progressPercentage: 75
    }
  }
];

export const currentUser: Family = mockFamilies[0];

export const activeMissions: Mission[] = [
  {
    id: 'm1',
    title: 'Coach A1 Cleanliness Challenge',
    description: 'Maintain coach average score above 8.5 for next 2 hours',
    type: 'coach',
    target: 85,
    current: 82,
    reward: 1000,
    ecoCredits: 20,
    deadline: new Date(Date.now() + 2 * 60 * 60 * 1000),
    isActive: true,
    participants: ['1', '2', '3']
  },
  {
    id: 'm2',
    title: 'Perfect Berth Maintenance',
    description: 'Keep your berth area spotless until Mumbai',
    type: 'individual',
    target: 100,
    current: 85,
    reward: 500,
    ecoCredits: 10,
    isActive: true,
    participants: ['1']
  },
  {
    id: 'm3',
    title: 'Train-wide Eco Challenge',
    description: 'Entire train to earn 500+ eco-credits collectively',
    type: 'train',
    target: 500,
    current: 287,
    reward: 2000,
    ecoCredits: 50,
    deadline: new Date(Date.now() + 8 * 60 * 60 * 1000),
    isActive: true,
    participants: mockFamilies.map(f => f.id)
  }
];

export const coachData: CoachData = {
  id: 'a1',
  trainNumber: '12951',
  coachNumber: 'A1',
  totalFamilies: 3,
  averageScore: 8.2,
  totalPoints: 6580,
  currentMission: activeMissions[0],
  families: mockFamilies
};

export const availableRewards: Reward[] = [
  {
    id: 'r1',
    title: '10% Discount on Next Journey',
    description: 'Get 10% off your next train booking',
    cost: 30,
    type: 'discount',
    available: true,
    image: '🎫'
  },
  {
    id: 'r2',
    title: 'Railway Heritage Mug',
    description: 'Eco-friendly mug made from recycled materials',
    cost: 25,
    type: 'merchandise',
    available: true,
    image: '☕'
  },
  {
    id: 'r3',
    title: 'Priority Boarding Pass',
    description: 'Skip the queue for your next journey',
    cost: 20,
    type: 'priority',
    available: true,
    image: '⚡'
  },
  {
    id: 'r4',
    title: 'Plant a Tree Donation',
    description: 'Contribute to railway afforestation projects',
    cost: 15,
    type: 'donation',
    available: true,
    image: '🌳'
  }
];

export const recentScores: CleanlinessScore[] = [
  {
    id: 's1',
    familyId: '1',
    area: 'berth',
    scoreBefore: 7.5,
    scoreAfter: 9.2,
    improvement: 1.7,
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    aiValidated: true,
    points: 170
  },
  {
    id: 's2',
    familyId: '1',
    area: 'table',
    scoreBefore: 6.8,
    scoreAfter: 8.9,
    improvement: 2.1,
    timestamp: new Date(Date.now() - 45 * 60 * 1000),
    aiValidated: true,
    points: 210
  },
  {
    id: 's3',
    familyId: '1',
    area: 'floor',
    scoreBefore: 8.1,
    scoreAfter: 9.5,
    improvement: 1.4,
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    aiValidated: true,
    points: 140
  }
];