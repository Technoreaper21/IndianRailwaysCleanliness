import { CleanlinessScore } from '../types';

export const calculatePoints = (improvement: number, area: string): number => {
  const basePoints = improvement * 100;
  const areaMultiplier = {
    'toilet': 1.5,
    'berth': 1.2,
    'table': 1.1,
    'seat': 1.0,
    'floor': 1.0,
    'general': 0.8
  };

  return Math.round(basePoints * (areaMultiplier[area as keyof typeof areaMultiplier] || 1));
};

export const getScoreColor = (score: number): string => {
  if (score >= 9) return 'text-green-600';
  if (score >= 7) return 'text-yellow-600';
  if (score >= 5) return 'text-orange-600';
  return 'text-red-600';
};

export const getScoreGrade = (score: number): string => {
  if (score >= 9.5) return 'A+';
  if (score >= 9) return 'A';
  if (score >= 8) return 'B+';
  if (score >= 7) return 'B';
  if (score >= 6) return 'C+';
  if (score >= 5) return 'C';
  return 'D';
};

export const simulateAIScore = (): number => {
  // Simulate AI cleanliness scoring (in real app, this would call AI service)
  return Math.round((Math.random() * 3 + 7) * 10) / 10;
};

export const calculateEcoCredits = (points: number): number => {
  return Math.floor(points / 100);
};